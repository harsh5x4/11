﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace XmlDocumentDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public XmlDocument LoadXML()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(@"..\..\XMLFile\products.xml");
            return doc;
        }

        private void btnProduct_Click(object sender, RoutedEventArgs e)
        {
            XmlDocument document = LoadXML();

            XmlNodeList prodList = document.GetElementsByTagName("Product");

            MessageBox.Show("Number of Products : " + prodList.Count);
        }

        private void btnQuantity_Click(object sender, RoutedEventArgs e)
        {
            int quantity = 0;
            XmlDocument document = LoadXML();

            XmlNodeList prodList = document.GetElementsByTagName("ProductID");

            foreach (XmlNode prod in prodList)
            {
                int prodQty = XmlConvert.ToInt32(prod.Attributes.GetNamedItem("quantity").Value);
                quantity = quantity + prodQty;
            }

            MessageBox.Show("Total Product Quantity : " + quantity);
        }
    }
}
