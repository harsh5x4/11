﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQToObjectsDemo
{
    public class Product
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public int Price { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Product> prodList = new List<Product>();

            prodList.Add(new Product() { ID = 101, Name = "Notebook", Category = "Stationary", Price = 30 });
            prodList.Add(new Product() { ID = 102, Name = "Doll", Category = "Toys", Price = 200 });
            prodList.Add(new Product() { ID = 103, Name = "EarPhone", Category = "Accessories", Price = 150 });
            prodList.Add(new Product() { ID = 104, Name = "Pencil", Category = "Stationary", Price = 3 });
            prodList.Add(new Product() { ID = 105, Name = "Mechanica", Category = "Toys", Price = 750 });
            prodList.Add(new Product() { ID = 106, Name = "Blocks", Category = "Toys", Price = 240 });
            prodList.Add(new Product() { ID = 107, Name = "Screen Guard", Category = "Accessories", Price = 500 });
            prodList.Add(new Product() { ID = 108, Name = "Cover", Category = "Accessories", Price = 350 });
            prodList.Add(new Product() { ID = 109, Name = "Pen", Category = "Stationary", Price = 30 });
            prodList.Add(new Product() { ID = 110, Name = "Stamps", Category = "Stationary", Price = 60 });
            prodList.Add(new Product() { ID = 111, Name = "Mouse Sheet", Category = "Accessories", Price = 100 });
            prodList.Add(new Product() { ID = 112, Name = "Black Board", Category = "Stationary", Price = 300 });
            prodList.Add(new Product() { ID = 113, Name = "Chalks", Category = "Stationary", Price = 30 });

            //var price = prodList.Where(p => p.Price > 150);
            var price = from prod in prodList
                        where prod.Price > 150
                        select prod;

            Console.WriteLine("Products whose price is greater than 150");
            foreach (var p in price)
            {
                Console.WriteLine(p.ID + "\t" + p.Name + "\t" + p.Price + "\t" + p.Category);
            }

            //var sortbyName = prodList.OrderBy(p => p.Name);
            var sortbyName = from prod in prodList
                             orderby prod.Name
                             select prod;
            
            Console.WriteLine("\nProducts sorted as per Name");
            foreach (var p in sortbyName)
            {
                Console.WriteLine(p.ID + "\t" + p.Name + "\t" + p.Price + "\t" + p.Category);
            }


            //var startwith = prodList.Where(p => p.Name.StartsWith("B"));
            var startwith = from prod in prodList
                            where prod.Name.StartsWith("B")
                            select prod;

            Console.WriteLine("\nProducts whose name starts with B");
            foreach (var p in startwith)
            {
                Console.WriteLine(p.ID + "\t" + p.Name + "\t" + p.Price + "\t" + p.Category);
            }

            var groupperCat = prodList.GroupBy(p => p.Category);

            Console.WriteLine("\nGroupwise Products as per Category : ");
            foreach (IGrouping<string, Product> item in groupperCat)
            {
                Console.WriteLine("Category Name : " + item.Key);
                foreach (var p in item)
                {
                    Console.WriteLine(p.ID + "\t" + p.Name + "\t" + p.Price);
                }
            }
            Console.ReadKey();
        }
    }
}
