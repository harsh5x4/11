﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DisconnectedArchitectureDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        SqlCommandBuilder cmdBuild;

        public MainWindow()
        {
            InitializeComponent();

            con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["TrainingCon"].ConnectionString;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        public void ShowData()
        {
            da = new SqlDataAdapter("SELECT * FROM Student_master", con);
            cmdBuild = new SqlCommandBuilder(da);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da.Fill(ds, "Student");

            dgStudent.DataContext = ds.Tables["Student"];
        }

        public void Clear()
        {
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDeptCode.Text = "";
            txtDOB.Text = "";
            txtAddress.Text = "";
            txtYear.Text = "";

            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;

            txtStudCode.IsReadOnly = false;
            txtStudName.IsReadOnly = false;
            txtDOB.IsEnabled = true;
            txtYear.IsReadOnly = false;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Student"].NewRow();

            dr["Stud_Code"] = txtStudCode.Text;
            dr["Stud_Name"] = txtStudName.Text;
            dr["Dept_Code"] = txtDeptCode.Text;
            dr["Stud_Dob"] = txtDOB.Text;
            dr["Address"] = txtAddress.Text;
            dr["Stud_Year"] = txtYear.Text;

            ds.Tables["Student"].Rows.Add(dr);

            int records = da.Update(ds, "Student");

            if (records > 0)
            {
                MessageBox.Show("Record Added Successfully");
                Clear();
            }
            else
                MessageBox.Show("Record not added");
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Student"].Rows.Find(txtStudCode.Text);
            if (dr != null)
            {
                txtStudCode.Text = dr["Stud_Code"].ToString();
                txtStudName.Text = dr["Stud_Name"].ToString();
                txtDeptCode.Text = dr["Dept_Code"].ToString();
                txtDOB.Text = dr["Stud_Dob"].ToString();
                txtAddress.Text = dr["Address"].ToString();
                txtYear.Text = dr["Stud_Year"].ToString();

                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                MessageBox.Show("Record not found for student code " + txtStudCode.Text);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < ds.Tables["Student"].Rows.Count; i++)
            {
                if (ds.Tables["Student"].Rows[i]["Stud_Code"].ToString() == txtStudCode.Text)
                {
                    ds.Tables["Student"].Rows[i]["Dept_Code"] = txtDeptCode.Text;
                    ds.Tables["Student"].Rows[i]["Address"] = txtAddress.Text;
                }
            }

            int records = da.Update(ds, "Student");
            if (records > 0)
            {
                MessageBox.Show("Record updated successfully for student code " + txtStudCode.Text);
                Clear();
            }
            else
                MessageBox.Show("Record not updated for student code " + txtStudCode.Text);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
