﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace ConnectedArchitecture
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;");
        SqlCommand cmd;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        public void ShowData()
        {
            cmd = new SqlCommand("SELECT * FROM Student_master", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            con.Close();

            dgStudent.DataContext = dt;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO Student_master (Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address, Stud_Year) VALUES (@scode, @sname, @dcode, @dob, @add, @year)", con);

            SqlParameter scode = new SqlParameter();
            scode.ParameterName = "@scode";
            scode.DbType = DbType.Decimal;
            scode.Direction = ParameterDirection.Input;
            scode.Value = txtStudCode.Text;
            cmd.Parameters.Add(scode);

            cmd.Parameters.Add("@sname", SqlDbType.VarChar, 40);
            cmd.Parameters["@sname"].Value = txtStudName.Text;

            cmd.Parameters.AddWithValue("@dcode", txtDeptCode.Text);
            cmd.Parameters.AddWithValue("@dob", txtDOB.Text);
            cmd.Parameters.AddWithValue("@add", txtAddress.Text);
            cmd.Parameters.AddWithValue("@year", txtYear.Text);

            con.Open();

            int recordsAffected = cmd.ExecuteNonQuery();

            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student Record Inserted Successfully");
                ShowData();
                Clear();
            }
            else
                MessageBox.Show("Student Record not Inserted");
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("usp_SearchStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@SCode", txtStudCode.Text);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                txtStudCode.Text = dr["Stud_Code"].ToString();
                txtStudName.Text = dr["Stud_Name"].ToString();
                txtDeptCode.Text = dr["Dept_Code"].ToString();
                txtDOB.Text = dr["Stud_Dob"].ToString();
                txtAddress.Text = dr["Address"].ToString();
                txtYear.Text = dr["Stud_Year"].ToString();
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
                txtStudCode.IsReadOnly = true;
                txtStudName.IsEnabled = false;
                txtDOB.IsEnabled = false;
                txtYear.IsReadOnly = false;
            }
            else
                MessageBox.Show("Record not available for Student code " + txtStudCode.Text);
            con.Close();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("usp_UpdateStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@SCode", txtStudCode.Text);
            cmd.Parameters.AddWithValue("@DCode", txtDeptCode.Text);
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Record updated successfully for Student Code " + txtStudCode.Text);
                ShowData();
                Clear();
            }
            else
            {
                MessageBox.Show("Record not updated for Student Code " + txtStudCode.Text);
            }
        }

        public void Clear()
        {
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDeptCode.Text = "";
            txtDOB.Text = DateTime.Today.ToShortDateString();
            txtAddress.Text = "";
            txtYear.Text = "";

            txtStudCode.IsReadOnly = false;
            txtStudName.IsEnabled = true;
            txtDOB.IsEnabled = true;
            txtYear.IsReadOnly = false;

            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("usp_DeleteStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@SCode", txtStudCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Record deleted successfully for Student Code " + txtStudCode.Text);
                ShowData();
                Clear();
            }
            else
                MessageBox.Show("Record not deleted for Student Code " + txtStudCode.Text);
        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("SELECT COUNT(*) FROM Student_master", con);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();

            MessageBox.Show("Number of Students : " + count);
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
