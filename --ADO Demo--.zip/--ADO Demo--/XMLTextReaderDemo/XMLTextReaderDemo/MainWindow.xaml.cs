﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace XMLTextReaderDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            int pi = 0;
            int el = 0;
            int at = 0;
            int cm = 0;
            int ws = 0;

            int prod = 0;

            XmlTextReader reader = new XmlTextReader(@"..\..\XMLFile\products2.xml");

            while (reader.Read())
            {
                XmlNodeType ntype = reader.NodeType;

                if(ntype == XmlNodeType.ProcessingInstruction)
                {
                    pi = pi + 1;
                    MessageBox.Show("Processing Instruction : " + reader.Name);
                }

                if (ntype == XmlNodeType.Element)
                {
                    el = el + 1;
                    MessageBox.Show("Element : " + reader.Name);
                    if (reader.Name == "Product")
                    {
                        prod = prod + 1;
                    }
                }

                if (ntype == XmlNodeType.Attribute)
                {
                    at = at + 1;
                    MessageBox.Show("Attribute : " + reader.Name);
                }

                if (ntype == XmlNodeType.Comment)
                {
                    cm = cm + 1;
                    MessageBox.Show("Comment : " + reader.Name);
                }

                if (ntype == XmlNodeType.Whitespace)
                {
                    ws = ws + 1;
                    MessageBox.Show("White Space : " + reader.Name);
                }
            }

            MessageBox.Show("Number of Processing Instructions : " + pi);
            MessageBox.Show("Number of Elements : " + el);
            MessageBox.Show("Number of Attributes : " + at);
            MessageBox.Show("Number of Comments : " + cm);
            MessageBox.Show("Number of Whitespaces : " + ws);
            MessageBox.Show("Number of Products : " + prod);
        }
    }
}
