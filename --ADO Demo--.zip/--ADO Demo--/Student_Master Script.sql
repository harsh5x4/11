select * from Student_master

exec sp_help Student_master
GO
CREATE PROC usp_InsertStudent
(
	@SCode			INT,
	@SName			VARCHAR(30),
	@DCode			INT,
	@DOB			DATE,
	@Address		VARCHAR(30),
	@Year			INT
)
AS
BEGIN
	INSERT INTO Student_master (Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address, Stud_Year)
	VALUES ( @SCode, @SName, @DCode, @DOB, @Address, @Year)
END
GO

CREATE PROC usp_UpdateStudent
(
	@SCode			INT,
	@DCode			INT,
	@Address		VARCHAR(30)
)
AS
BEGIN
	UPDATE Student_master
	SET	Dept_Code = @DCode,
		Address	= @Address
	WHERE Stud_Code = @SCode
END

GO

CREATE PROC usp_DeleteStudent
(
	@SCode		INT
)
AS
BEGIN
	DELETE FROM Student_master WHERE Stud_Code = @SCode
END
GO
CREATE PROC usp_SearchStudent
(
	@SCode		INT
)
AS
BEGIN
	SELECT * FROM Student_master WHERE Stud_Code = @SCode
END
GO

CREATE PROC usp_DisplayStudent
AS
BEGIN
	SELECT * FROM Student_master 
END