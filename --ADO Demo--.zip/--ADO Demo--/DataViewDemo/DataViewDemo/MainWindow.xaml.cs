﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace DataViewDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser");

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Student_master", con);

            DataSet ds = new DataSet();
            da.Fill(ds, "Stud");

            //DataView dvStud = new DataView(ds.Tables["Stud"], "Dept_Code=10", "Stud_Name", DataViewRowState.Unchanged);

            DataView dvStud = new DataView(ds.Tables["Stud"]);
            dvStud.RowFilter = "Dept_Code=10";
            dvStud.Sort = "Stud_Name";

            dgStudent.DataContext = dvStud;
        }
    }
}
