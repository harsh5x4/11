﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace ConnectedArchitecture
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;");
        SqlCommand cmd;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        public void ShowData()
        {
            cmd = new SqlCommand("SELECT * FROM Student_master", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            con.Close();

            dgStudent.DataContext = dt;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO Student_master (Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address, Stud_Year) VALUES (@scode, @sname, @dcode, @dob, @add, @year)", con);

            SqlParameter scode = new SqlParameter();
            scode.ParameterName = "@scode";
            scode.DbType = DbType.Decimal;
            scode.Direction = ParameterDirection.Input;
            scode.Value = txtStudCode.Text;
            cmd.Parameters.Add(scode);

            cmd.Parameters.Add("@sname", SqlDbType.VarChar, 40);
            cmd.Parameters["@sname"].Value = txtStudName.Text;

            cmd.Parameters.AddWithValue("@dcode", txtDeptCode.Text);
            cmd.Parameters.AddWithValue("@dob", txtDOB.Text);
            cmd.Parameters.AddWithValue("@add", txtAddress.Text);
            cmd.Parameters.AddWithValue("@year", txtYear.Text);

            con.Open();

            int recordsAffected = cmd.ExecuteNonQuery();

            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student Record Inserted Successfully");
                ShowData();
            }
            else
                MessageBox.Show("Student Record not Inserted");
        }
    }
}
