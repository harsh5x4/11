﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SqlCredentialDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        System.Security.SecureString securePwd = new System.Security.SecureString();



        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TrainingCon"].ConnectionString);
            securePwd.MakeReadOnly();
            con.Credential = new SqlCredential(txtUserName.Text, securePwd);
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Student_master", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Stud");

            dgStudent.DataContext = ds.Tables["Stud"];
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            securePwd.AppendChar(Convert.ToChar(e.Key.ToString().ToLower()));
        }
    }
}
