﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace SqlDataReaderDemo3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;");
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student_master", con);

            List<Student> studList = new List<Student>();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Student stud = new Student();
                    stud.StudCode = (int)((decimal)dr["Stud_Code"]);
                    stud.StudName = dr["Stud_Name"].ToString();
                    stud.DeptCode = (int)((decimal)dr["Dept_Code"]);
                    stud.DOB = Convert.ToDateTime(dr["Stud_Dob"]);
                    stud.Address = dr["Address"].ToString();
                    stud.Year = (int)dr["Stud_Year"];

                    studList.Add(stud);
	
                }
            }

            con.Close();

            dgStudent.DataContext = studList;
        }
    }
}
