﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace SqlDataReaderDemo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;";

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT * FROM Student_master";
            cmd.Connection = con;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    MessageBox.Show("Student Code : " + dr["Stud_Code"].ToString()
                    + " Student Name : " + dr["Stud_Name"] +
                    " Department Code : " + dr["Dept_Code"] +
                    " Student Date of Birth : " + dr["Stud_Dob"] +
                    " Address : " + dr["Address"] +
                    " Student Year : " + dr["Stud_Year"]);
                }
            }
            else
            {
                MessageBox.Show("Data not available");
            }

            con.Close();
        }
    }
}
