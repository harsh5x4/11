﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace DataTableDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        DataTable dtProd;
        DataTable dtCat;
        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            DataRow newRow = dtProd.NewRow();
            newRow["ProductID"] = txtProductID.Text;
            newRow["ProductName"] = txtProductName.Text;
            newRow["Price"] = txtPrice.Text;
            newRow["Quantity"] = txtQuantity.Text;
            newRow["CatID"] = txtCategoryID.Text;

            dtProd.Rows.Add(newRow);

            dgProduct.DataContext = dtProd;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dtCat = new DataTable("Category");
            dtCat.Columns.Add("CatID", typeof(System.Int32));
            dtCat.Columns.Add("CatName", typeof(System.String));

            dtCat.PrimaryKey = new DataColumn[] { dtCat.Columns["CatID"] };

            DataRow row1 = dtCat.NewRow();
            row1["CatID"] = 10;
            row1["CatName"] = "Stationary";
            dtCat.Rows.Add(row1);

            DataRow row2 = dtCat.NewRow();
            row2["CatID"] = 20;
            row2["CatName"] = "Accessories";
            dtCat.Rows.Add(row2);

            DataRow row3 = dtCat.NewRow();
            row3["CatID"] = 30;
            row3["CatName"] = "Toys";
            dtCat.Rows.Add(row3);


            dtProd = new DataTable("Product");

            DataColumn dcID = new DataColumn();
            dcID.ColumnName = "ProductID";
            dcID.DataType = typeof(System.Int32);
            dtProd.Columns.Add(dcID);

            DataColumn dcName = new DataColumn("ProductName", typeof(System.String));
            dtProd.Columns.Add(dcName);

            dtProd.Columns.Add("Price", typeof(System.Int32));

            dtProd.Columns.Add("Quantity", typeof(System.Int32));

            dtProd.Columns.Add("CatID", typeof(System.Int32));

            dtProd.PrimaryKey = new DataColumn[] { dcID };

            ForeignKeyConstraint CatProdFK = new ForeignKeyConstraint("CatProdFK", dtCat.Columns["CatID"], dtProd.Columns["CatID"]);
            CatProdFK.DeleteRule = Rule.None;

            dtProd.Constraints.Add(CatProdFK);

            dgProduct.DataContext = dtProd;
        }
    }
}
